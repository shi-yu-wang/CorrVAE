This is the sample code of CorrVAE handling dSprites dataset

For training, run train.py.
For testing, refer to test.py.

dSprites dataset is in data folder.